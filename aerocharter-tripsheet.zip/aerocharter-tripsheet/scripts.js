// Trip Brief Generator Scripts
let flightCounter = 1;
let legCounter = 1;

// Add a new flight entry
function addFlightEntry() {
    const flightEntries = document.getElementById('flightEntries');
    const newId = 'flight-' + flightCounter;
    
    const flightEntry = document.createElement('div');
    flightEntry.className = 'flight-entry';
    flightEntry.id = newId;
    
    flightEntry.innerHTML = `
        <button type="button" class="remove-flight" onclick="removeEntry('${newId}')">×</button>
        <div class="form-row">
            <div class="form-group">
                <label for="flightDate-${flightCounter}">Date</label>
                <input type="date" id="flightDate-${flightCounter}" name="flightDate-${flightCounter}">
            </div>
            <div class="form-group">
                <label for="flightNumber-${flightCounter}">Flight Number</label>
                <input type="text" id="flightNumber-${flightCounter}" name="flightNumber-${flightCounter}" placeholder="e.g., AR123">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="tailNumber-${flightCounter}">Tail Number</label>
                <input type="text" id="tailNumber-${flightCounter}" name="tailNumber-${flightCounter}" placeholder="e.g., N123AR">
            </div>
            <div class="form-group">
                <label for="ferryFlight-${flightCounter}">Ferry Flight</label>
                <div class="checkbox-container">
                    <input type="checkbox" id="ferryFlight-${flightCounter}" name="ferryFlight-${flightCounter}">
                    <label for="ferryFlight-${flightCounter}" class="checkbox-label">Mark as Ferry Flight</label>
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="numPax-${flightCounter}">No of Pax</label>
                <input type="number" id="numPax-${flightCounter}" name="numPax-${flightCounter}" placeholder="e.g., 4" min="0">
            </div>
        </div>
    `;
    
    flightEntries.appendChild(flightEntry);
    
    // Show remove button for the first entry
    if (flightCounter === 1) {
        document.querySelector('#flight-0 .remove-flight').style.display = 'flex';
    }
    
    flightCounter++;
}

// Add a new routing leg entry
function addLegEntry() {
    const legEntries = document.getElementById('legEntries');
    const newId = 'leg-' + legCounter;
    
    const legEntry = document.createElement('div');
    legEntry.className = 'leg-entry';
    legEntry.id = newId;
    
    legEntry.innerHTML = `
        <button type="button" class="remove-leg" onclick="removeEntry('${newId}')">×</button>
        <div class="form-row">
            <div class="form-group">
                <label for="departureAirport-${legCounter}">Departure Airport</label>
                <input type="text" id="departureAirport-${legCounter}" name="departureAirport-${legCounter}" placeholder="e.g., LAX">
            </div>
            <div class="form-group">
                <label for="departureFBO-${legCounter}">Departure FBO</label>
                <input type="text" id="departureFBO-${legCounter}" name="departureFBO-${legCounter}" placeholder="e.g., Signature">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="arrivalAirport-${legCounter}">Arrival Airport</label>
                <input type="text" id="arrivalAirport-${legCounter}" name="arrivalAirport-${legCounter}" placeholder="e.g., SFO">
            </div>
            <div class="form-group">
                <label for="arrivalFBO-${legCounter}">Arrival FBO</label>
                <input type="text" id="arrivalFBO-${legCounter}" name="arrivalFBO-${legCounter}" placeholder="e.g., Signature">
            </div>
        </div>
    `;
    
    legEntries.appendChild(legEntry);
    
    // Show remove button for the first entry
    if (legCounter === 1) {
        document.querySelector('#leg-0 .remove-leg').style.display = 'flex';
    }
    
    legCounter++;
}

// Remove an entry (flight or leg)
function removeEntry(id) {
    const element = document.getElementById(id);
    if (element) {
        element.remove();
    }
}

// Collect all form data
function collectFormData() {
    const tripData = {
        tripNumber: document.getElementById('tripNumber').value,
        pilotShowtime: document.getElementById('pilotShowtime').value,
        csrShowtime: document.getElementById('csrShowtime').value,
        leadCharterer: document.getElementById('leadCharterer').value,
        g2kHeadsUp: document.getElementById('g2kHeadsUp').value,
        numGuests: document.getElementById('numGuests').value,
        reasonForTrip: document.getElementById('reasonForTrip').value,
        catering: document.getElementById('catering').value,
        preferredBeverage: document.getElementById('preferredBeverage').value,
        allergies: document.getElementById('allergies').value,
        crewRequests: document.getElementById('crewRequests').value,
        customsFuelStop: document.getElementById('customsFuelStop').value,
        hostAssistance: document.getElementById('hostAssistance').value,
        additionalInfo: document.getElementById('additionalInfo').value,
        flights: [],
        legs: []
    };
    
    // Collect flight entries
    const flightEntries = document.querySelectorAll('.flight-entry');
    flightEntries.forEach((entry) => {
        const id = entry.id.split('-')[1];
        const flight = {
            date: document.getElementById(`flightDate-${id}`).value,
            flightNumber: document.getElementById(`flightNumber-${id}`).value,
            tailNumber: document.getElementById(`tailNumber-${id}`).value,
            isFerry: document.getElementById(`ferryFlight-${id}`).checked,
            numPax: document.getElementById(`numPax-${id}`).value
        };
        tripData.flights.push(flight);
    });
    
    // Collect leg entries
    const legEntries = document.querySelectorAll('.leg-entry');
    legEntries.forEach((entry) => {
        const id = entry.id.split('-')[1];
        const leg = {
            departureAirport: document.getElementById(`departureAirport-${id}`).value,
            departureFBO: document.getElementById(`departureFBO-${id}`).value,
            arrivalAirport: document.getElementById(`arrivalAirport-${id}`).value,
            arrivalFBO: document.getElementById(`arrivalFBO-${id}`).value
        };
        tripData.legs.push(leg);
    });
    
    return tripData;
}

// Generate the trip brief
function generateTripBrief() {
    const tripData = collectFormData();
    
    // Save the trip data to localStorage if it has a trip number
    if (tripData.tripNumber) {
        saveTrip(tripData);
    }
    
    showPreview(tripData);
}

// Show the preview with the collected data
function showPreview(tripData) {
    // Hide form and main header, then show preview
    document.getElementById('form-container').style.display = 'none';
    document.querySelector('.main-header').style.display = 'none';
    document.getElementById('preview').style.display = 'block';
    
    // Update trip title
    const tripTitle = tripData.tripNumber ? `Trip ${tripData.tripNumber} - Crew Briefsheet` : 'Trip - Crew Briefsheet';
    document.getElementById('tripTitle').textContent = tripTitle;
    
    // Helper function to convert text to uppercase if it exists
    function toUpperCase(text) {
        return text ? text.toUpperCase() : '--';
    }
    
    // Update basic information
    document.getElementById('pilotShowtimeValue').textContent = tripData.pilotShowtime ? `${tripData.pilotShowtime} MINS` : '--';
    document.getElementById('csrShowtimeValue').textContent = tripData.csrShowtime ? `${tripData.csrShowtime} MINS` : '--';
    document.getElementById('leadChartererValue').textContent = toUpperCase(tripData.leadCharterer);
    
    // Handle G2K/Heads Up field
    const g2kHeadsUpElement = document.getElementById('g2kHeadsUpValue');
    g2kHeadsUpElement.textContent = toUpperCase(tripData.g2kHeadsUp);
    
    document.getElementById('numGuestsValue').textContent = tripData.numGuests || '--';
    document.getElementById('reasonForTripValue').textContent = toUpperCase(tripData.reasonForTrip);
    
    // Update additional information
    document.getElementById('cateringValue').textContent = toUpperCase(tripData.catering);
    document.getElementById('preferredBeverageValue').textContent = toUpperCase(tripData.preferredBeverage);
    document.getElementById('allergiesValue').textContent = toUpperCase(tripData.allergies);
    document.getElementById('crewRequestsValue').textContent = toUpperCase(tripData.crewRequests);
    document.getElementById('customsFuelStopValue').textContent = toUpperCase(tripData.customsFuelStop);
    document.getElementById('hostAssistanceValue').textContent = toUpperCase(tripData.hostAssistance);
    document.getElementById('additionalInfoValue').textContent = toUpperCase(tripData.additionalInfo);
    
    // Update flight information table
    const flightInfoTable = document.getElementById('flightInfoTable');
    // Clear existing rows except header
    while (flightInfoTable.children.length > 1) {
        flightInfoTable.removeChild(flightInfoTable.lastChild);
    }
    
    // Add flight rows
    tripData.flights.forEach(flight => {
        const row = document.createElement('div');
        row.className = flight.isFerry ? 'table-row ferry-flight' : 'table-row';
        
        // Format date if available
        let formattedDate = '--';
        if (flight.date) {
            const date = new Date(flight.date);
            const day = date.getDate().toString().padStart(2, '0');
            const month = date.toLocaleString('en-US', { month: 'short' }).toUpperCase();
            const year = date.getFullYear().toString().slice(-2);
            formattedDate = `${day}${month}${year}`;
        }
        
        const flightType = flight.isFerry ? '(FERRY)' : 'Pax Charter';
        
        row.innerHTML = `
            <div class="table-cell">${formattedDate}</div>
            <div class="table-cell">${flight.flightNumber ? flight.flightNumber.toUpperCase() : '--'}</div>
            <div class="table-cell">${flight.tailNumber ? flight.tailNumber.toUpperCase() : '--'}</div>
            <div class="table-cell">${flightType}</div>
            <div class="table-cell">${flight.numPax || '--'}</div>
        `;
        flightInfoTable.appendChild(row);
    });
    
    // Update routing information table
    const routingInfoTable = document.getElementById('routingInfoTable');
    // Clear existing rows except header
    while (routingInfoTable.children.length > 1) {
        routingInfoTable.removeChild(routingInfoTable.lastChild);
    }
    
    // Add routing rows
    tripData.legs.forEach((leg, index) => {
        const row = document.createElement('div');
        
        // Check if the corresponding flight is a ferry flight
        // If there's a matching flight index and it's a ferry flight, apply the ferry-flight class
        const isFerryFlight = index < tripData.flights.length && tripData.flights[index].isFerry;
        row.className = isFerryFlight ? 'table-row ferry-flight' : 'table-row';
        
        row.innerHTML = `
            <div class="table-cell">${leg.departureAirport ? leg.departureAirport.toUpperCase() : '--'}</div>
            <div class="table-cell">${leg.departureFBO ? leg.departureFBO.toUpperCase() : '--'}</div>
            <div class="table-cell">${leg.arrivalAirport ? leg.arrivalAirport.toUpperCase() : '--'}</div>
            <div class="table-cell">${leg.arrivalFBO ? leg.arrivalFBO.toUpperCase() : '--'}</div>
        `;
        routingInfoTable.appendChild(row);
    });
}

// Go back to the form
function goBack() {
    document.getElementById('preview').style.display = 'none';
    document.getElementById('form-container').style.display = 'block';
    document.querySelector('.main-header').style.display = 'flex';
}

// Download the trip brief as PDF
function downloadAsPDF() {
    // Get the trip brief element
    const element = document.querySelector('.trip-brief');
    
    // Ensure the footer is visible
    const footer = document.querySelector('.brief-footer');
    footer.style.display = 'block';
    
    // Store original title
    const originalTitle = document.querySelector('h1').textContent;
    
    // Change the title for PDF generation
    document.querySelector('h1').textContent = 'Crew Charter Trip Briefsheet';
    
    const filename = document.getElementById('tripTitle').textContent.replace(/\s+/g, '_') + '.pdf';
    
    // Add some temporary padding to the bottom to ensure footer is visible
    element.style.paddingBottom = '50px';
    
    // Use html2canvas and jsPDF
    html2canvas(element, { 
        scale: 2, 
        useCORS: true,
        allowTaint: true,
        scrollY: -window.scrollY,
        height: element.offsetHeight + 100, // Add extra height to capture footer
        windowHeight: element.offsetHeight + 100
    }).then(canvas => {
        const imgData = canvas.toDataURL('image/jpeg', 1.0);
        const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        
        // Adjust the ratio to ensure the entire content fits
        // Use a slightly smaller ratio to ensure everything fits
        const ratio = Math.min(pdfWidth / imgWidth, (pdfHeight - 5) / imgHeight) * 0.95;
        const imgX = (pdfWidth - imgWidth * ratio) / 2;
        const imgY = 5; // Start a bit higher on the page
        
        pdf.addImage(imgData, 'JPEG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
        
        pdf.save(filename);
        
        // Restore original title and remove extra padding
        document.querySelector('h1').textContent = originalTitle;
        element.style.paddingBottom = '';
    });
}

// Clear form function
function clearForm() {
    // Reset the form
    document.getElementById('tripForm').reset();
    
    // Clear all flight entries except the first one
    const flightEntries = document.querySelectorAll('.flight-entry');
    for (let i = 1; i < flightEntries.length; i++) {
        flightEntries[i].remove();
    }
    
    // Clear all leg entries except the first one
    const legEntries = document.querySelectorAll('.leg-entry');
    for (let i = 1; i < legEntries.length; i++) {
        legEntries[i].remove();
    }
    
    // Reset counters
    flightCounter = 1;
    legCounter = 1;
    
    // Hide remove buttons for first entries
    document.querySelector('#flight-0 .remove-flight').style.display = 'none';
    document.querySelector('#leg-0 .remove-leg').style.display = 'none';
}

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    // Add initial flight and leg entries
    addFlightEntry();
    addLegEntry();
    
    // Load saved trips from localStorage
    loadSavedTrips();
});

// Trip storage functions
function saveTrip(tripData) {
    // Generate a unique ID for the trip if it doesn't have one
    if (!tripData.id) {
        tripData.id = Date.now().toString();
    }
    
    // Get existing trips from localStorage
    let savedTrips = JSON.parse(localStorage.getItem('savedTrips') || '{}');
    
    // Add or update this trip
    savedTrips[tripData.tripNumber] = tripData;
    
    // Save back to localStorage
    localStorage.setItem('savedTrips', JSON.stringify(savedTrips));
    
    // Show confirmation message
    alert(`Trip ${tripData.tripNumber} has been saved.`);
    
    // Refresh the search results if they're visible
    if (document.getElementById('searchResults').style.display !== 'none') {
        searchTrips();
    }
}

function loadSavedTrips() {
    // This function is called on page load to check if there are any saved trips
    const savedTrips = JSON.parse(localStorage.getItem('savedTrips') || '{}');
    // Keep the placeholder text simple
    document.getElementById('tripSearchInput').placeholder = 'Search by Trip Number...';
}

function closeSearchResults() {
    document.getElementById('searchResults').style.display = 'none';
}

function searchTrips() {
    const searchTerm = document.getElementById('tripSearchInput').value.trim().toUpperCase();
    const savedTrips = JSON.parse(localStorage.getItem('savedTrips') || '{}');
    const resultsContainer = document.getElementById('resultsContainer');
    const searchResults = document.getElementById('searchResults');
    
    // Clear previous results
    resultsContainer.innerHTML = '';
    
    // Filter trips based on search term
    const filteredTrips = Object.values(savedTrips).filter(trip => {
        if (!searchTerm) return true; // If no search term, show all
        return trip.tripNumber.toUpperCase().includes(searchTerm);
    });
    
    if (filteredTrips.length === 0) {
        resultsContainer.innerHTML = '<p>No saved trips found.</p>';
    } else {
        // Sort trips by trip number
        filteredTrips.sort((a, b) => a.tripNumber.localeCompare(b.tripNumber));
        
        // Create a list of trip items
        filteredTrips.forEach(trip => {
            const tripItem = document.createElement('div');
            tripItem.className = 'trip-item';
            
            const tripInfo = document.createElement('div');
            tripInfo.className = 'trip-info';
            tripInfo.textContent = `Trip ${trip.tripNumber} - ${trip.leadCharterer ? trip.leadCharterer.toUpperCase() : 'No Lead Charterer'}`;
            
            const tripActions = document.createElement('div');
            tripActions.className = 'trip-item-actions';
            
            const loadButton = document.createElement('button');
            loadButton.textContent = 'Load';
            loadButton.onclick = function() { loadTrip(trip); };
            
            const downloadButton = document.createElement('button');
            downloadButton.textContent = 'Download PDF';
            downloadButton.onclick = function() { downloadTripPDF(trip); };
            
            // Slack button removed
            
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.onclick = function() { deleteTrip(trip.tripNumber); };
            
            tripActions.appendChild(loadButton);
            tripActions.appendChild(downloadButton);
            tripActions.appendChild(deleteButton);
            
            tripItem.appendChild(tripInfo);
            tripItem.appendChild(tripActions);
            
            resultsContainer.appendChild(tripItem);
        });
    }
    
    // Show the results section
    searchResults.style.display = 'block';
}

function loadTrip(tripData) {
    // Populate the form with the saved trip data
    document.getElementById('tripNumber').value = tripData.tripNumber || '';
    document.getElementById('pilotShowtime').value = tripData.pilotShowtime || '';
    document.getElementById('csrShowtime').value = tripData.csrShowtime || '';
    document.getElementById('leadCharterer').value = tripData.leadCharterer || '';
    document.getElementById('g2kHeadsUp').value = tripData.g2kHeadsUp || '';
    document.getElementById('numGuests').value = tripData.numGuests || '';
    document.getElementById('reasonForTrip').value = tripData.reasonForTrip || '';
    document.getElementById('catering').value = tripData.catering || '';
    document.getElementById('preferredBeverage').value = tripData.preferredBeverage || '';
    document.getElementById('allergies').value = tripData.allergies || '';
    document.getElementById('crewRequests').value = tripData.crewRequests || '';
    document.getElementById('customsFuelStop').value = tripData.customsFuelStop || '';
    document.getElementById('hostAssistance').value = tripData.hostAssistance || '';
    document.getElementById('additionalInfo').value = tripData.additionalInfo || '';
    
    // Clear existing flight and leg entries
    const flightEntries = document.querySelectorAll('.flight-entry');
    flightEntries.forEach((entry, index) => {
        if (index > 0) { // Keep the first one
            entry.remove();
        }
    });
    
    const legEntries = document.querySelectorAll('.leg-entry');
    legEntries.forEach((entry, index) => {
        if (index > 0) { // Keep the first one
            entry.remove();
        }
    });
    
    // Reset flight and leg counters
    flightCounter = 0;
    legCounter = 0;
    
    // Add flight entries from saved data
    if (tripData.flights && tripData.flights.length > 0) {
        // Remove the initial flight entry
        document.getElementById('flight-0').remove();
        
        tripData.flights.forEach(flight => {
            addFlightEntry();
            const id = flightCounter - 1;
            document.getElementById(`flightDate-${id}`).value = flight.date || '';
            document.getElementById(`flightNumber-${id}`).value = flight.flightNumber || '';
            document.getElementById(`tailNumber-${id}`).value = flight.tailNumber || '';
            document.getElementById(`ferryFlight-${id}`).checked = flight.isFerry || false;
            document.getElementById(`numPax-${id}`).value = flight.numPax || '';
        });
    }
    
    // Add leg entries from saved data
    if (tripData.legs && tripData.legs.length > 0) {
        // Remove the initial leg entry
        document.getElementById('leg-0').remove();
        
        tripData.legs.forEach(leg => {
            addLegEntry();
            const id = legCounter - 1;
            document.getElementById(`departureAirport-${id}`).value = leg.departureAirport || '';
            document.getElementById(`departureFBO-${id}`).value = leg.departureFBO || '';
            document.getElementById(`arrivalAirport-${id}`).value = leg.arrivalAirport || '';
            document.getElementById(`arrivalFBO-${id}`).value = leg.arrivalFBO || '';
        });
    }
    
    // Hide the search results
    document.getElementById('searchResults').style.display = 'none';
    
    // Show confirmation message
    alert(`Trip ${tripData.tripNumber} has been loaded.`);
}

function downloadTripPDF(tripData) {
    // First load the trip data into the form
    loadTrip(tripData);
    
    // Then generate the preview
    generateTripBrief();
    
    // Finally trigger the PDF download
    setTimeout(() => {
        downloadAsPDF();
    }, 500); // Give a small delay to ensure the preview is fully rendered
}

function deleteTrip(tripNumber) {
    if (confirm(`Are you sure you want to delete Trip ${tripNumber}?`)) {
        // Get existing trips from localStorage
        let savedTrips = JSON.parse(localStorage.getItem('savedTrips') || '{}');
        
        // Delete this trip
        delete savedTrips[tripNumber];
        
        // Save back to localStorage
        localStorage.setItem('savedTrips', JSON.stringify(savedTrips));
        
        // Refresh the search results
        searchTrips();
        
        // Update the search placeholder
        const tripCount = Object.keys(savedTrips).length;
        document.getElementById('tripSearchInput').placeholder = tripCount > 0 ? 
            `Search by Trip Number... (${tripCount} saved)` : 
            'Search by Trip Number...';
    }
}

function sendSavedTripToSlack(tripNumber) {
    // Just download the PDF instead
    downloadSavedTripAsPDF(tripNumber);
}

// Export and import functionality for sharing trips
function exportAllTrips() {
    const savedTrips = localStorage.getItem('savedTrips') || '{}';
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(savedTrips);
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "trip_briefs_export.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function importTrips() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const importedTrips = JSON.parse(e.target.result);
                    
                    // Merge with existing trips
                    let savedTrips = JSON.parse(localStorage.getItem('savedTrips') || '{}');
                    const importedTripCount = Object.keys(importedTrips).length;
                    
                    // Merge the imported trips with existing trips
                    savedTrips = { ...savedTrips, ...importedTrips };
                    
                    // Save back to localStorage
                    localStorage.setItem('savedTrips', JSON.stringify(savedTrips));
                    
                    // Update the search placeholder
                    loadSavedTrips();
                    
                    // Show confirmation message
                    alert(`Successfully imported ${importedTripCount} trip briefs.`);
                    
                    // Refresh the search results if they're visible
                    if (document.getElementById('searchResults').style.display !== 'none') {
                        searchTrips();
                    }
                } catch (error) {
                    alert('Error importing trips: ' + error.message);
                }
            };
            reader.readAsText(file);
        }
    };
    input.click();
}
